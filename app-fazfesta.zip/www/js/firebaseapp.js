var config = {
    apiKey: "AIzaSyAHFQYF3QV4KYhvZkTnNKmnXCkB7YEBpoQ",
    authDomain: "fazfesta-c56c9.firebaseapp.com",
    databaseURL: "https://fazfesta-c56c9.firebaseio.com",
    projectId: "fazfesta-c56c9",
    storageBucket: "fazfesta-c56c9.appspot.com",
    messagingSenderId: "151147608818"
  };
  firebase.initializeApp(config);
